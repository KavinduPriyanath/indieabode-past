<?php
include('db.php');
$res=mysqli_query($con,"select * from content");
while($row=mysqli_fetch_assoc($res)){
?>
<div contenteditable="true" id="<?php echo $row['id']?>"><?php echo $row['content']?></div><input type="button" onclick="updateData('<?php echo $row['id']?>')" value="Update"><div id="msg<?php echo $row['id']?>"></div>
<br/><br/>
<?php } ?>

<script src="jquery-3.6.0.min.js"></script>
<script>

function updateData(id){
	let html=jQuery('#'+id).html();
	jQuery.ajax({
		url:'update.php',
		type:'post',
		data:'html='+html+'&id='+id,
		success:function(result){
			jQuery('#msg'+id).html(result);
		}
		
	});
}
</script>